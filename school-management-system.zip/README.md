# School-Management-System---PHP-MySQL

Available Functions

  * Student Management;
  * Subject Management;
  * Class Room Management;
  * Exam Management;
  * Attendance Management;
  * Teacher Management;
  * Parents Management;
  * User Management;
  * School Notice Distribution;
  
Setup Instruction

01. Create new MySQL database 'schoolnew' and import provided schoolnew.sql file.
02. Put all files and folders in your host's public directory.


Demo 

Visit [School Management System Demo](http://schoolms.gearhostpreview.com)

* Teacher Login - Email: tea@tea.tea Password:tea;
* Student Login - Email: stu@stu.stu Password:stu;
* Parent Login - Email: par@par.par Password:par;

  
